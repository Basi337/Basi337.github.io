// ViewHandler.js

import EnergyList from './ENergyList.js';
import Energy from './Energy.js';

function ViewHandler() {}

ViewHandler.prototype.bind = function() {
    const setPercentageBtn = document.getElementById('setPercentageBtn');
    const calculateEnergyUsageBtn = document.getElementById('calculateEnergyUsageBtn');
    const calculateEnergyUsageBetweenDatesBtn = document.getElementById('calculateEnergyUsageBetweenDatesBtn');

    setPercentageBtn.addEventListener('click', () => this.handleSetPercentage());
    // calculateEnergyUsageBtn.addEventListener('click', () => this.handleCalculateEnergyUsage());
    // calculateEnergyUsageBetweenDatesBtn.addEventListener('click', () => this.handleCalculateEnergyUsageBetweenDates());
};

ViewHandler.prototype.render = function(data) {
    document.getElementById('current-input').textContent = data.input;
    document.getElementById('current-output').textContent = data.output;
    document.getElementById('battery-status').textContent = data.batteryPercentage;
    document.getElementById('battery-time').textContent = data.remainingTime;

    const batteryChargeElement = document.getElementById('batteryCharge');
    batteryChargeElement.style.width = `${data.batteryPercentage}%`;

    if (data.batteryPercentage <= 25) {
        batteryChargeElement.className = 'battery-charge low';
    } else if (data.batteryPercentage <= 75) {
        batteryChargeElement.className = 'battery-charge medium';
    } else {
        batteryChargeElement.className = 'battery-charge high';
    }
};

ViewHandler.prototype.handleSetPercentage = function () {
    const energyId = document.getElementById('energyId').value;
    const energyList = new EnergyList();
    const energyData = energyList.getEnergyById(energyId);

    if (energyData) {
        const energy = new Energy(energyData.energyId, energyData.input, energyData.output, energyData.batteryPercentage);
        const remainingTime = energy.calculateBatteryTime(energyData.input, energyData.output, energyData.batteryPercentage);
        this.render({
            input: energyData.input,
            output: energyData.output,
            batteryPercentage: energyData.batteryPercentage,
            remainingTime: remainingTime
        });
    } else {
        alert("Energy data not found for the entered ID.");
    }
};

ViewHandler.prototype.handleCalculateEnergyUsage = function () {
    // Implementation for calculating energy usage
};

ViewHandler.prototype.handleCalculateEnergyUsageBetweenDates = function () {
    // Implementation for calculating energy usage between dates
};

export default ViewHandler;
