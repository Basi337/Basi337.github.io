// script.js

import ViewHandler from './ViewHandler.js';

document.addEventListener("DOMContentLoaded", function () {
    let viewHandler = new ViewHandler();
    viewHandler.bind();
});
